import java.util.Scanner;

/**
 * The FloridianToothRecords program maintains tooth records for family members
 * in Florida, allowing for printing of records, extraction of teeth, and
 * calculation of root canal indices.
 *
 */
public class FloridianToothRecords {
    // Constants
    private static final int MAX_FAMILY_MEMBERS = 6;
    private static final int MAX_TEETH = 8;

    // Variables to hold family member names and teeth records
    private static String[] familyNames = new String[MAX_FAMILY_MEMBERS];
    private static char[][][] teethRecords = new char[MAX_FAMILY_MEMBERS][2][MAX_TEETH];

    /**
     * Main method for running the Floridian Tooth Records program. Displays menu
     * options and processes user selections for managing tooth records.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Welcome to the Floridian Tooth Records");
        System.out.println("--------------------------------------");

        int familySize = getFamilySize(scanner);
        recordFamilyData(scanner, familySize);

        boolean exit = false;
        while (!exit) {
            char choice = displayMenu(scanner);
            switch (choice) {
                case 'P':
                case 'p':
                    printFamilyTeethRecords(familySize);
                    break;
                case 'E':
                case 'e':
                    extractTooth(scanner, familySize);
                    break;
                case 'R':
                case 'r':
                    reportRootCanalIndices(familySize);
                    break;
                case 'X':
                case 'x':
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid menu option, try again.");
            }
        }
        System.out.println("Exiting the Floridian Tooth Records :-)");
        scanner.close();
    }

    /**
     * Gets the family size from user input, ensuring the size is within allowed
     * limits.
     *
     * @param scanner the Scanner object for user input
     * @return the number of family members
     */
    private static int getFamilySize(Scanner scanner) {
        int familySize;
        do {
            System.out.print("Please enter the number of people in the family: ");
            familySize = scanner.nextInt();
            if (familySize < 1 || familySize > MAX_FAMILY_MEMBERS) {
                System.out.println("Invalid number of people, try again.");
            }
        } while (familySize < 1 || familySize > MAX_FAMILY_MEMBERS);
        return familySize;
    }

    /**
     * Records the names and teeth details (upper and lower) for each family
     * member.
     *
     * @param scanner    the Scanner object for user input
     * @param familySize the number of family members
     */
    private static void recordFamilyData(Scanner scanner, int familySize) {
        for (int i = 0; i < familySize; i++) {
            System.out.print("Please enter the name for family member " + (i + 1) + ": ");
            familyNames[i] = scanner.next();
            recordTeeth(scanner, i, "uppers");
            recordTeeth(scanner, i, "lowers");
        }
    }

    /**
     * Records teeth details for either the upper or lower row for a specified
     * family member.
     *
     * @param scanner     the Scanner object for user input
     * @param memberIndex the index of the family member
     * @param layer       the layer ("uppers" or "lowers") for recording teeth
     */
    private static void recordTeeth(Scanner scanner, int memberIndex, String layer) {
        char[] teeth;
        boolean validInput;
        do {
            System.out.print("Please enter the " + layer + " for " + familyNames[memberIndex] + ": ");
            teeth = scanner.next().toUpperCase().toCharArray();
            validInput = validateTeethInput(teeth);
            if (!validInput) {
                System.out.println("Invalid teeth types or too many teeth, try again.");
            }
        } while (!validInput);
        if (layer.equals("uppers")) {
            System.arraycopy(teeth, 0, teethRecords[memberIndex][0], 0, teeth.length);
        } else {
            System.arraycopy(teeth, 0, teethRecords[memberIndex][1], 0, teeth.length);
        }
    }

    /**
     * Validates the teeth input, ensuring the input does not exceed the maximum
     * number and contains valid tooth types.
     *
     * @param teeth an array of characters representing teeth types
     * @return true if the input is valid; false otherwise
     */
    private static boolean validateTeethInput(char[] teeth) {
        if (teeth.length > MAX_TEETH) {
            return false;
        }
        for (char tooth : teeth) {
            if (tooth != 'I' && tooth != 'B' && tooth != 'M') {
                return false;
            }
        }
        return true;
    }

    /**
     * Displays the menu and gets the user's choice.
     *
     * @param scanner the Scanner object for user input
     * @return the user's menu choice as a character
     */
    private static char displayMenu(Scanner scanner) {
        System.out.print("(P)rint, (E)xtract, (R)oot, e(X)it: ");
        return scanner.next().charAt(0);
    }

    /**
     * Prints the tooth records for all family members.
     *
     * @param familySize the number of family members
     */
    private static void printFamilyTeethRecords(int familySize) {
        for (int i = 0; i < familySize; i++) {
            System.out.println(familyNames[i]);
            System.out.print("  Uppers: ");
            printTeethRow(teethRecords[i][0]);
            System.out.print("  Lowers: ");
            printTeethRow(teethRecords[i][1]);
        }
    }

    /**
     * Prints a row of teeth with positions.
     *
     * @param teeth an array of characters representing a row of teeth
     */
    private static void printTeethRow(char[] teeth) {
        for (int j = 0; j < MAX_TEETH; j++) {
            if (teeth[j] != '\0') {
                System.out.print(" " + (j + 1) + ":" + teeth[j]);
            }
        }
        System.out.println();
    }

    /**
     * Allows the user to extract a tooth for a specified family member.
     *
     * @param scanner    the Scanner object for user input
     * @param familySize the number of family members
     */
    private static void extractTooth(Scanner scanner, int familySize) {
        int row;
        String name;
        int memberIndex;

        do {
            System.out.print("Which family member: ");
            name = scanner.next();
            memberIndex = findFamilyMember(name, familySize);
            if (memberIndex == -1) {
                System.out.println("Invalid family member, try again.");
            }
        } while (memberIndex == -1);

        char layer;
        do {
            System.out.print("Which tooth layer (U)pper or (L)ower: ");
            layer = scanner.next().toUpperCase().charAt(0);
            if (layer == 'U') {
                row = 0;
                break;
            } else if (layer == 'L') {
                row = 1;
                break;
            } else {
                System.out.println("Invalid layer, try again.");
            }
        } while (true);

        int toothNum;
        boolean validTooth;
        do {
            System.out.print("Which tooth number: ");
            toothNum = scanner.nextInt();
            validTooth = toothNum >= 1 && toothNum <= MAX_TEETH;
            if (!validTooth) {
                System.out.println("Invalid tooth number, try again.");
            } else if (teethRecords[memberIndex][row][toothNum - 1] == 'M') {
                System.out.println("This tooth is already missing, please choose another tooth number.");
                validTooth = false;
            }
        } while (!validTooth);

        teethRecords[memberIndex][row][toothNum - 1] = 'M';
        System.out.println("Tooth extracted successfully.");
    }

    /**
     * Finds a family member by name.
     *
     * @param name       the name of the family member to find
     * @param familySize the number of family members
     * @return the index of the family member if found; -1 otherwise
     */
    private static int findFamilyMember(String name, int familySize) {
        for (int i = 0; i < familySize; i++) {
            if (familyNames[i].equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Reports the root canal indices by counting types of teeth and calculating
     * the indices.
     *
     * @param familySize the number of family members
     */
    private static void reportRootCanalIndices(int familySize) {
        int numIncisors = 0, numBicuspids = 0, numMissing = 0;

        for (int i = 0; i < familySize; i++) {
            numIncisors += countTeethType(teethRecords[i], 'I');
            numBicuspids += countTeethType(teethRecords[i], 'B');
            numMissing += countTeethType(teethRecords[i], 'M');
        }
        calculateRootCanalIndices(numIncisors, numBicuspids, numMissing);
    }

    /**
     * Counts a specific type of tooth for a family member's teeth.
     *
     * @param teeth  a 2D array representing upper and lower teeth rows
     * @param target the tooth type to count ('I', 'B', or 'M')
     * @return the count of the specified tooth type
     */
    private static int countTeethType(char[][] teeth, char target) {
        int count = 0;
        for (int j = 0; j < 2; j++) {
            for (int k = 0; k < MAX_TEETH; k++) {
                if (teeth[j][k] == target) {
                    count++;
                }
            }
        }
        return count;
    }

    /**
     * Calculates and displays the root canal indices based on the counts of
     * incisors, bicuspids, and missing teeth using the formula Ix^2 + Bx - M = 0.
     *
     * @param I the number of incisors
     * @param B the number of bicuspids
     * @param M the number of missing teeth
     */
    private static void calculateRootCanalIndices(int I, int B, int M) {
        // Calculate the correct discriminant for the equation
        double discriminant = Math.pow(B, 2) + 4 * I * M;

        if (discriminant >= 0) {
            // Calculate both roots of the quadratic equation
            double root1 = (-B + Math.sqrt(discriminant)) / (2 * I);
            double root2 = (-B - Math.sqrt(discriminant)) / (2 * I);

            // Print the roots with the specified phrasing
            System.out.printf("One root canal at %.2f%n", root1);
            System.out.printf("Another root canal at %.2f%n", root2);
        } else {
            // If there are no real roots, inform the user
            System.out.println("No real root canals.");
        }
    }
}









